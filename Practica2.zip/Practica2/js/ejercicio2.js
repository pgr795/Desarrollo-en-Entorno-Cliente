window.onload = inicio;

function inicio() {
    document.formulario.onsubmit = validar;
}

function validar() {
    let envio = true;
    let mensaje = "";

    let nombre = document.formulario.nombre.value.trim();
    let expRegNombre;

    if (!expRegNombre.test(nombre)){
		envio=false;
		mensaje+="Nombre \n";
	}
    else {
        document.formulario.nombre.value = "";
    }

    let apellido = document.formulario.apellido.value;
    let expRegApellido;

    if (!expRegApellido.test(apellido)) {
        envio = false;
        mensaje += "Error validacion Apellidos \n";
    }
    else {
        document.formulario.apellido.value = "";
    }

    let nif = document.formulario.nif.value.trim();
    let expRegNif;

    if (!expRegNif.test(nif)) {
        envio = false;
        mensaje += "Error validacion Nif \n"
    }
    else {
        document.formulario.nif.value = "";
    }

    let nacimiento = document.formulario.nacimiento.value.trim();
    let expRegNacimiento;

    if (!expRegNacimiento.test(nacimiento)) {
        envio = false;
        mensaje += "Error validacion Nacimiento \n"
    }
    else {
        document.formulario.nacimiento.value = "";
    }

    let tipoVia = document.formulario.tipoVia.value.trim();
    let expRegTipoVia;

    if (!expRegTipoVia.test(tipoVia)) {
        envio = false;
        mensaje += "Error validacion tipoVia \n"
    }
    else {
        document.formulario.tipoVia.value = "";
    }

    let denominacionVia = document.formulario.denominacionVia.value;
    let expRegDenominacionVia;

    if (!expRegDenominacionVia.test(denominacionVia)) {
        envio = false;
        mensaje += "Error validacion denominacionVia \n"
    }
    else {
        document.formulario.denominacionVia.value = "";
    }

    let Vnumero = document.formulario.numero.value.trim();
    let expRegNumeros;

    if (!expRegNumeros.test(Vnumero)) {
        envio = false;
        mensaje += "Error validacion numeros \n"
    }
    else {
        document.formulario.numero.value = "";
    }

    let vemail = document.formulario.email.value.trim();
    let expRegEmail;

    if (!expRegEmail.test(vemail)) {
        envio = false;
        mensaje += "Error validacion email \n"
    }
    else {
        document.formulario.nacimiento.value = "";
    }

    let web = document.formulario.web.value.trim();
    let expRegWeb;
    if (!expRegWeb.test(web)) {
        envio = false;
        mensaje += "Error validacion web \n"
    }
    else {
        document.formulario.nacimiento.value = "";
    }

    if (envio == false) {
        alert(mensaje);
    }
    else {
        return envio;
    }
}
